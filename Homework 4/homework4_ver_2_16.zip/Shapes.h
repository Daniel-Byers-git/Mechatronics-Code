#include "Point.h"
#include <string>
using namespace std;

class Polygon 
{
    protected:
        Point vertex[10];
        int numPoints;
        string shapeName;
    public:
        Polygon() : vertex({}),
                    numPoints(0),
                    shapeName("") {}
        void setPoints(double x[], double y[], int numP); //defined below
        void displayPoints(); // Writes shapeName and all vertices to the screen, defined below
        double getPerimeter (); //defined below
};

    //Definitions of Polygon functions
    void Polygon::setPoints(double x[], double y[], int numP)
    {
        for (int i = 0; i < numP; i++)
        {
            vertex[i].setValues(x[i], y[i]);
        }
    }
    void Polygon::displayPoints()
    {
        cout << "Points for " << shapeName << ": " << endl; 
        for (int i = 0; i < numPoints; i++)
        {
            vertex[i].display();    
        }
    }
    double Polygon::getPerimeter()
    {
        double perim = 0;
        for (int i = 0; i < numPoints - 1; i++)
        {
            perim += vertex[i].dist(vertex[i+1]);
        }
        perim += vertex[numPoints - 1].dist(vertex[0]);
        return perim;
    }

// Triangle: Subclass of Polygon
class Triangle : public Polygon 
{
    public:
        Triangle(double x1, double y1, double x2, double y2, double x3, double y3);
        double getArea();
};
    //Triangle funtion defintions
    Triangle::Triangle(double x1, double y1, double x2, double y2, double x3, double y3)
    {
        numPoints = 3;
        double x[3] = {x1, x2, x3}, y[3] = {y1, y2, y3};
        setPoints(x, y, numPoints);
    }
    double Triangle::getArea()
    {
        //need to implement: (1/2)*b*h, look at assignment prompt
        // \/\/ This is filler
        double area;
        area = 12;
        return area;
    }

//Euilateral Triangle: Subclass of Triangle: Subclass of Polygon
class EquilateralTriangle : public Triangle 
{
    public:
        // Displays error if given points do not make equilateral triangle
        EquilateralTriangle(double x1, double y1, double x2, double y2, double x3, double y3);
};
    //Definitions for Equalateral triangle functions
    EquilateralTriangle::EquilateralTriangle(double x1, double y1, double x2, double y2, double x3, double y3)
    {
        Triangle(x1, y1, x2, y2, x3, y3);
        shapeName = "Equilateral Triangle";
    }


// class RightTriangle : public Triangle 
// {
//     public:
//         // Displays error if given points do not make right triangle
//         RightTriangle(double x1, double y1, double x2, double y2, double x3, double y3);
// };

// class Parallelogram : public Polygon 
// {
//     public:
//         // Displays error if given points do not make parallelogram
//         Parallelogram(double x1, double y1, double x2, double y2, 
//                       double x3, double y3, double x4, double y4);
//         double getArea();
// };


// class Rectangle : public Parallelogram 
// {
//     public:
//         // Displays error if given points do not make rectangle
//         Rectangle(double x1, double y1, double x2, double y2, 
//                   double x3, double y3, double x4, double y4);
// };
